# ezGfx
Semi-private repo about a simple graphics engine project.
Same philosophy as https://github.com/OneLoneCoder/olcPixelGameEngine
